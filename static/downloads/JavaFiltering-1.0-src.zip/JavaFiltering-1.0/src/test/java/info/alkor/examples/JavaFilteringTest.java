
package info.alkor.examples;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Maciej Stachurski <alkor@konto.pl>
 */
public class JavaFilteringTest {
	
	@Test
	public void testGetMessage() {
		assertEquals("Hello from JavaFiltering version 1.0!", new JavaFiltering().getMessage());
	}
}