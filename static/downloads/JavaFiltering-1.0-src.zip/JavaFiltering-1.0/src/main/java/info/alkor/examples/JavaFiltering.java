
package info.alkor.examples;

/**
 *
 * @author Maciej Stachurski <alkor@konto.pl>
 */
public class JavaFiltering {
	public String getMessage() {
		return Constants.MESSAGE;
	}
}
