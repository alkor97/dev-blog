
package info.alkor.examples;

public interface Constants {
	String MESSAGE = "Hello from ${JavaFiltering.projectName}!";
}
